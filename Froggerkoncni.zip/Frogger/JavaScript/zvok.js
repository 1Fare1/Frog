document.addEventListener('DOMContentLoaded', () => {
    const storedVolume = localStorage.getItem('volume');
    if (storedVolume == null) {
        Howler.volume(0.5);
    } else {
        Howler.volume(storedVolume / 100);
        console.log(storedVolume);
    }

    const volumeSlider = document.getElementById('volumeSlider');

    const updateVolumeIcon = () => {
       // const volumeIcon = Howler.volume() === 0 ? './img/muted-icon.png' : './img/volume-icon.png';
        //volumeSlider.style.background = `url('${volumeIcon}') center/cover no-repeat`;
    };
  
    volumeSlider.addEventListener('input', () => {
        const volumeValue = volumeSlider.value;
        Howler.volume(volumeValue / 100);
        updateVolumeIcon();


        console.log("Nova vrednost glasnosti:", volumeValue);
    });
  
  updateVolumeIcon();
  loadVolumeFromLocalStorage();

});
function changeVolume(value) {
  
    console.log('Volume changed to:', value);
  
    localStorage.setItem('volume', value);
  }
  function loadVolumeFromLocalStorage() {
    const storedVolume = localStorage.getItem('volume');
    console.log("stored volume ", storedVolume);

    if (storedVolume !== null) {
        const volumeSlider = document.getElementById('volumeSlider');
        const volumeValue = parseFloat(storedVolume);

        if (volumeValue === 0) {
            volumeSlider.value = 50;
        } else {
            volumeSlider.value = volumeValue;
        }

        Howler.volume(volumeValue / 100);
    }
}
const audio = {
   /* videoBackground: new Howl({
      src: "/sound/background.mp4",
      loop: true
  }),*/
  audioClick: new Howl({
      src: "/sound/buttonclick.wav",
  }),
  audioHover: new Howl({
      src: "/sound/buttonrollover.wav",
  }),
  trcenje: new Howl({
    src: "/sound/splat.mp3",
}),
skok: new Howl({
    src: "/sound/skok.mp3",
}),
splash: new Howl({
    src: "/sound/splash.mp3",
}),
};
