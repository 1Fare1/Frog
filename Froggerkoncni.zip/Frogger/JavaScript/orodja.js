
function animate(){     
    //OzadjeZvok.play();
    //StartTime.time; 
    //time_start;
    Kontekt_Objekt_efekti.clearRect(0, 0, Objekt_efekti.width, Objekt_efekti.height);
    Kontekt_Objekt_debla_zabe.clearRect(0, 0, Objekt_efekti.width, Objekt_efekti.height);
    Kontekt_Objekt_zaba.clearRect(0, 0, Objekt_efekti.width, Objekt_efekti.height);
    Kontekt_Objekt_avtomobili.clearRect(0, 0, Objekt_efekti.width, Objekt_efekti.height);
    Kontekt_Objekt_trava.clearRect(0, 0, Objekt_efekti.width, Objekt_efekti.height);
    
    handleRipples();
    Kontekt_Objekt_debla_zabe.drawImage(background_lvl2, 0, 0, Objekt_debla_zabe.width, Objekt_debla_zabe.height);
    handleParticles();
    frogger.update();
    frogger.draw();
    
    handleObstacles();
    handleScoreBoard();
  
    frame++;
    requestAnimationFrame(animate);
    time_trenutni();
}

animate();



window.addEventListener('keydown', function(e) {
    // Branje trenutnih vrednosti gumbov za premikanje
    const movementKey1 = document.getElementById('movementKey1').value.toUpperCase().charCodeAt(0);
    const movementKey2 = document.getElementById('movementKey2').value.toUpperCase().charCodeAt(0);
    const movementKey3 = document.getElementById('movementKey3').value.toUpperCase().charCodeAt(0);
    const movementKey4 = document.getElementById('movementKey4').value.toUpperCase().charCodeAt(0);

    // Nastavitev vrednosti ključev v polju tipke
    tipke = [];
    tipke[e.keyCode] = true;

    // Preverjanje, če so pritisnjene tipke za premikanje in klic funkcije frogger.jump()
    if (tipke[movementKey1] || tipke[movementKey2] || tipke[movementKey3] || tipke[movementKey4]) {
        frogger.jump();
    }
});

window.addEventListener('keyup', function(e){
    delete tipke[e.keyCode];
    frogger.moving = false;     
    frogger.frameX = 0;
});

const HIGH_SCORES_KEY = 'frogger_high_scores';


function saveHighScore(score) {
    let highScores = JSON.parse(localStorage.getItem(HIGH_SCORES_KEY)) || [];
    highScores.push(score);
    highScores.sort((a, b) => b - a); 
    highScores = highScores.slice(0, 10); 
    localStorage.setItem(HIGH_SCORES_KEY, JSON.stringify(highScores));
}

function getHighScores() {
    return JSON.parse(localStorage.getItem(HIGH_SCORES_KEY)) || [];
}

function scored() {
    score++;
    gameSpeed += 0.05;
    frogger.x = Objekt_efekti.width / 2 - frogger.width / 2;
    frogger.y = Objekt_efekti.height - frogger.height - 40;
    Porabljen_cas = 0;
    saveHighScore(score); 
    displayHighScores(); 
}

function handleScoreBoard(){
    Kontekt_Objekt_avtomobili.fillStyle ="black";
    Kontekt_Objekt_avtomobili.strokeStyle ="black";
    Kontekt_Objekt_avtomobili.font = '15px Verdana';
    Kontekt_Objekt_avtomobili.strokeText('Rešene žabice', 10, 190);
    Kontekt_Objekt_avtomobili.font = '60px Verdana';
    Kontekt_Objekt_avtomobili.fillText(score, 10, 175);
    Kontekt_Objekt_avtomobili.font = '15px Verdana';
    Kontekt_Objekt_avtomobili.strokeText('Umrlih žabic: ' + collisionCount, 470, 175);
    Kontekt_Objekt_avtomobili.strokeText('Hitrost igre: ' + gameSpeed.toFixed(1), 470, 195);
    //Kontekt_Objekt_avtomobili.strokeText('Čas: ' + Porabljen_cas, 10, 215);
}



function collision(first, second){
    return !(first.x > second.x + second.width-10 ||   
             first.x + first.width < second.x-10  ||  
             first.y > second.y + second.height-10||  
             first.y + first.height < second.y-10)    
                                                
}

function resetGame(){   
    frogger.x = Objekt_efekti.width/2 - frogger.width/2; 
    frogger.y = Objekt_efekti.height - frogger.height - 40; 
    life --;
    collisionCount++;
   // gameSpeed = 1;
    Porabljen_cas = 0;
}


function scored() {
    score++;
    gameSpeed += 0.05;
    frogger.x = Objekt_efekti.width / 2 - frogger.width / 2;
    frogger.y = Objekt_efekti.height - frogger.height - 40;
    Porabljen_cas = 0;
    saveHighScore(score); 
    displayHighScores(); 
}


function displayHighScores() {
    const highScores = getHighScores();
    const modalContent = document.querySelector('.modal-content');
    modalContent.innerHTML = '<span class="close" onclick="closeBestScoresModal()">&times;</span><h2>Najboljši rezultati</h2>';
    if (highScores.length > 0) {
        modalContent.innerHTML += '<ol>';
        highScores.forEach((score, index) => {
            modalContent.innerHTML += `<li>${index + 1}. ${score}</li>`;
        });
        modalContent.innerHTML += '</ol>';
    } else {
        modalContent.innerHTML += '<p>Ni doseženih rezultatov.</p>';
    }
}


const bestScoresButton = document.getElementById('bestScoresButton');
bestScoresButton.addEventListener("click", function(event) {
    event.preventDefault();
    displayHighScores();
});
