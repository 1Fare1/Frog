const Objekt_efekti = document.getElementById('Objekt_efekti');
const Kontekt_Objekt_efekti = Objekt_efekti.getContext('2d');
Objekt_efekti.width = 600;
Objekt_efekti.height = 600;

const Objekt_debla_zabe = document.getElementById('Objekt_debla_zabe');
const Kontekt_Objekt_debla_zabe = Objekt_debla_zabe.getContext('2d');
Objekt_debla_zabe.width = 600;
Objekt_debla_zabe.height = 620;

const Objekt_zaba = document.getElementById('Objekt_zaba');
const Kontekt_Objekt_zaba = Objekt_zaba.getContext('2d');
Objekt_zaba.width = 600;
Objekt_zaba.height = 600;

const Objekt_avtomobili = document.getElementById('Objekt_avtomobili');
const Kontekt_Objekt_avtomobili = Objekt_avtomobili.getContext('2d');
Objekt_avtomobili.width = 600;
Objekt_avtomobili.height = 600;

const Objekt_trava = document.getElementById('Objekt_trava');
const Kontekt_Objekt_trava = Objekt_trava.getContext('2d');
Objekt_trava.width = 600;
Objekt_trava.height = 600;

const grid = 80;
let tipke = [];
let score = 0;
let life= 5;
let collisionCount = 0;
let frame = 0;
let gameSpeed = 1;
let safe = false;   


const particlesArray = [];
const maxParticles = 300;
const ripplesArray = [];
const carsArray = [];
const logsArray = [];  


const background_lvl2 = new Image();
background_lvl2.src = '/img/bg2.png'


const turtle = new Image();
turtle.src = '/img/zelve.png';

const log = new Image();
log.src = '/img/log4.png';

const car = new Image();
car.src = '/img/avti.png';
let numberOfCars = 3; 

const froggerSprite = new Image();
froggerSprite.src = '/img/Frame5.png';

const KonecIgreZvok = new Audio();
KonecIgreZvok.src = "/Sound/GameOverMusic.mp3"




const GAMESTAT = {
    PAUSED :0,
    RUNNING: 1,
    MENU: 2,
    GAMEOVER: 3,
    SETUP: 4
};

let Porabljen_cas = time_trenutni() - ZacetniCas();

function ZacetniCas(){
    const d = new Date();
    let time_zacetni = d.getTime();
    return time_zacetni;
}

function time_trenutni(){
    const d = new Date();
    let time_trenutni = d.getTime();
    return time_trenutni;
}

