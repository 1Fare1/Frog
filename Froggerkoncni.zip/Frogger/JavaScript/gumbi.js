function startGame() {
    document.querySelector('.menu').style.display = 'none';

    document.querySelector('.screen').style.display = 'none';

    document.querySelector('.wrapper').style.display = 'block';
    document.getElementById('endGameButton').style.display = 'block';

    
    initializeGame();
}


function initializeGame() {
    
}
console.log('Igra se inicializira...');

function endLife(){
  if(life == 1){
    score =0;
    gameSpeed =1;
    //collisionCount = 0;
    console.log("endlifefunkicja");
    life = 5;
  }
}

function endGame() {
console.log('Igra se končuje...');
document.querySelector('.menu').style.display = 'block';
document.querySelector('.screen').style.display = 'flex'; 
document.querySelector('.wrapper').style.display = 'none';
document.getElementById('endGameButton').style.display = 'none';
score = 0;
gameSpeed = 1
collisionCount = 0;
life = 5;
} 

function zapriokno() {
    window.close();
}

function openSettingsModal() {
    document.getElementById("settingsModal").style.display = "block";
  }
  
  function closeSettingsModal() {
    document.getElementById("settingsModal").style.display = "none";
  }
