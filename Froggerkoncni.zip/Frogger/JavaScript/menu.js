const video = document.getElementById("VideoBackgroung");
const sound = document.getElementById("sound");
const links = document.querySelectorAll("ul a");
const audioClick = document.getElementById("audioClick");
const audioHover = document.getElementById("audioHover");

sound.addEventListener("click",() => {
    sound.classList.toggle("fa-volume-up")

    if (video.muted === false){
        video.muted = true;
    } else {
        video.muted = false;
    }

   clickSound();
});

sound.addEventListener("mouseenter", hoverSound);
 
for (let i=0; i<links.length; i++){
    links[i].addEventListener("click",clickSound)
    links[i].addEventListener("mouseenter", hoverSound)

}

function clickSound() {
    audio.audioClick.play();
}

function hoverSound() {
   audio.audioHover.play();
}
function trcenjeSound() {
    audio.trcenje.play();
}
function skokSound(){
    audio.skok.play();
}

function splashSound(){
    audio.splash.play();
}

function updateKeyBinding(keyCode, newValue) {
    switch (keyCode) {
        case 38:
            movementKey1.value = newValue;
            break;
        case 40:
            movementKey2.value = newValue;
            break;
        case 37:
            movementKey3.value = newValue;
            break;
        case 39:
            movementKey4.value = newValue;
            break;
        default:
            break;
    }
}